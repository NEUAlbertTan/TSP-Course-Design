#include "ant.h"
//#define NULL -1

/*
* 输入：dimension 是数据的维数，srcFile是数据集，直接拿来用就行
* 输出：返回answer数组
*/
